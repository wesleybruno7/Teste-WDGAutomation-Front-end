var app = angular.module('app',['ngRoute']);

app.config(function($routeProvider, $locationProvider, $httpProvider) {

    $routeProvider

    // para a rota '/', carregaremos o template home.html
    .when('/', {
    templateUrl : 'views/login.html',
    controller: 'loginController',
    authorize: false
    })

    // para a rota '/login', carregaremos o template login.html
    .when('/login', {
    templateUrl : 'views/login.html',
    controller: 'loginController',
    authorize: false
    })

    // para a rota '/users', carregaremos o template users.html
    .when('/users', {
    templateUrl : 'views/users.html',
    controller: 'usersController',
    authorize: true
    })

    // para a rota '/404', carregaremos o template 404.html
    .when('/404', {
    templateUrl : 'views/404.html'
    })
    
    // caso não seja nenhum desses, redirecione para a rota '/404'
    .otherwise ({ redirectTo: '/404' });

});
